import { getStore } from "@netlify/blobs";
import { randomBytes, randomUUID, scryptSync, timingSafeEqual, createHmac } from "node:crypto";

const users=getStore("interclasse-users"), requests=getStore("interclasse-requests");
const messages=getStore("interclasse-messages"), roster=getStore("interclasse-roster");
const sessions=getStore("interclasse-sessions"), COOKIE="interclasse_session";
const json=(data,status=200,headers={})=>new Response(JSON.stringify(data),{status,headers:{"content-type":"application/json; charset=utf-8","cache-control":"no-store",...headers}});
const fail=(msg,status=400)=>json({error:msg},status);
const env=k=>process.env[k]||"";
const equal=(a,b)=>{const x=Buffer.from(String(a)),y=Buffer.from(String(b));return x.length===y.length&&timingSafeEqual(x,y)};
const hash=(p,s)=>scryptSync(p,s,64).toString("hex");
const sign=d=>createHmac("sha256",env("SESSION_SECRET")).update(d).digest("base64url");
const makeToken=p=>{const d=Buffer.from(JSON.stringify(p)).toString("base64url");return d+"."+sign(d)};
function verify(token){if(!env("SESSION_SECRET")||!token)return null;const [d,s]=token.split(".");if(!d||!s||!equal(s,sign(d)))return null;try{const p=JSON.parse(Buffer.from(d,"base64url").toString());return p.exp>Date.now()?p:null}catch{return null}}
function getCookie(req){const c=(req.headers.get("cookie")||"").split(";").map(x=>x.trim()).find(x=>x.startsWith(COOKIE+"="));return c?decodeURIComponent(c.slice(COOKIE.length+1)):""}
const cookie=t=>`${COOKIE}=${encodeURIComponent(t)}; Path=/; HttpOnly; Secure; SameSite=Strict; Max-Age=604800`;
async function startSession(subject,role){const sid=randomUUID();await sessions.setJSON(sid,{user:subject,role});return cookie(makeToken({sub:subject,role,sid,exp:Date.now()+604800000}))}
async function getSession(req){const p=verify(getCookie(req));if(!p)return null;const active=await sessions.get(p.sid,{type:"json"});if(!active||active.user!==p.sub||active.role!==p.role)return null;if(p.role==="admin")return{role:"admin",name:"Administrador",sid:p.sid};const u=await users.get(p.sub,{type:"json"});return u?{role:"member",username:p.sub,name:u.name,status:u.status,sid:p.sid}:null}
const key=s=>String(s||"").trim().toLowerCase(), valid=s=>/^[a-z0-9_]{3,24}$/.test(s);
async function list(store){const {blobs=[]}=await store.list();const arr=[];for(const b of blobs){const x=await store.get(b.key,{type:"json"});if(x)arr.push(x)}return arr}
export default async req=>{
 if(req.method!=="POST")return fail("Método não permitido.",405);
 const origin=req.headers.get("origin");if(origin){try{if(new URL(origin).host!==new URL(req.url).host)return fail("Origem não autorizada.",403)}catch{return fail("Origem inválida.",403)}}
 if(!env("ADMIN_CODE")||!env("SESSION_SECRET"))return fail("Falta configurar ADMIN_CODE e SESSION_SECRET nas variáveis do Netlify.",503);
 let b;try{if(Number(req.headers.get("content-length")||0)>1500000)return fail("Pedido muito grande.",413);b=await req.json()}catch{return fail("Dados inválidos.")}
 const action=String(b.action||"");
 try{
  if(action==="register"){
   const name=String(b.name||"").trim(),username=key(b.username),password=String(b.password||""),message=String(b.message||"").trim();
   if(name.length<2||name.length>70)return fail("Digite seu nome completo.");
   if(!valid(username))return fail("Usuário: 3 a 24 caracteres, letras, números ou _.");
   if(password.length<8||password.length>72)return fail("A senha deve ter de 8 a 72 caracteres.");
   if(message.length<3||message.length>500)return fail("Escreva uma mensagem para o ADM.");
   const salt=randomBytes(16).toString("hex"),user={username,name,salt,hash:hash(password,salt),status:"pending",created:Date.now()};
   const put=await users.setJSON(username,user,{onlyIfNew:true});if(!put.modified)return fail("Nome de usuário já está em uso.",409);
   const id=randomUUID();await requests.setJSON(id,{id,username,name,message,status:"pending",created:Date.now()});
   return json({ok:true});
  }
  if(action==="login"){
   const username=key(b.username),password=String(b.password||"");if(!valid(username))return fail("Usuário ou senha incorretos.",401);
   const u=await users.get(username,{type:"json"});if(!u||!equal(hash(password,u.salt),u.hash))return fail("Usuário ou senha incorretos.",401);
   return json({ok:true},200,{"set-cookie":await startSession(username,"member")});
  }
  if(action==="adminLogin"){
   if(!equal(String(b.code||""),env("ADMIN_CODE")))return fail("Código de ADM incorreto.",401);
   return json({ok:true},200,{"set-cookie":await startSession("admin","admin")});
  }
  if(action==="logout"){const s=await getSession(req);if(s)await sessions.delete(s.sid);return json({ok:true},200,{"set-cookie":`${COOKIE}=; Path=/; HttpOnly; Secure; SameSite=Strict; Max-Age=0`})}
  const s=await getSession(req);
  if(action==="session")return json(s?{loggedIn:true,role:s.role,name:s.name,status:s.status}:{loggedIn:false});
  if(action==="adminRequests"){
   if(s?.role!=="admin")return fail("Acesso restrito ao ADM.",403);
   const all=await list(requests);return json({requests:all.filter(x=>x.status==="pending").sort((a,b)=>a.created-b.created)});
  }
  if(action==="review"){
   if(s?.role!=="admin")return fail("Acesso restrito ao ADM.",403);
   const id=String(b.id||""),decision=String(b.decision||"");if(!["approved","rejected"].includes(decision))return fail("Decisão inválida.");
   const q=await requests.get(id,{type:"json"});if(!q||q.status!=="pending")return fail("Solicitação não encontrada.",404);
   q.status=decision;q.reviewed=Date.now();await requests.setJSON(id,q);
   const u=await users.get(q.username,{type:"json"});if(u){u.status=decision;await users.setJSON(q.username,u)}
   return json({ok:true});
  }
  if(action==="roster"){
   if(s?.role!=="admin")return fail("Acesso restrito ao ADM.",403);
   return json({players:(await list(roster)).sort((a,b)=>a.sport.localeCompare(b.sport)||a.name.localeCompare(b.name))});
  }
  if(action==="addPlayer"){
   if(s?.role!=="admin")return fail("Acesso restrito ao ADM.",403);
   const sport=String(b.sport||""),name=String(b.name||"").trim(),number=Number(b.number),shirtName=String(b.shirtName||"").trim();
   if(!["Futsal","Vôlei","Cabo de guerra"].includes(sport)||name.length<2||name.length>70||!Number.isInteger(number)||number<0||number>99||!shirtName||shirtName.length>20)return fail("Confira os dados do participante.");
   const id=randomUUID();await roster.setJSON(id,{id,sport,name,number,shirtName,created:Date.now()});return json({ok:true});
  }
  if(action==="deletePlayer"){
   if(s?.role!=="admin")return fail("Acesso restrito ao ADM.",403);
   await roster.delete(String(b.id||""));return json({ok:true});
  }
  if(action==="messages"){
   if(!s||(s.role!=="admin"&&s.status!=="approved"))return fail("Apenas participantes aprovados podem ver o chat.",403);
   const all=(await list(messages)).sort((a,b)=>a.created-b.created).slice(-150);return json({messages:all});
  }
  if(action==="sendMessage"){
   if(!s||(s.role!=="admin"&&s.status!=="approved"))return fail("Apenas participantes aprovados podem enviar mensagens.",403);
   const text=String(b.text||"").trim(),photo=String(b.photo||"");
   if(text.length>1500||photo.length>1250000||(!text&&!photo))return fail("Mensagem inválida.");
   if(photo&&!/^data:image\/(png|jpeg|webp);base64,[A-Za-z0-9+/=]+$/.test(photo))return fail("Foto inválida.");
   const id=randomUUID();await messages.setJSON(id,{id,sender:s.name,text,photo,created:Date.now()});return json({ok:true});
  }
  return fail("Ação desconhecida.",404);
 }catch(e){console.error(e);return fail("Erro interno. Tente novamente.",500)}
};